#include "config.h"
!
!  Copyright 2019-2020 SALMON developers
!
!  Licensed under the Apache License, Version 2.0 (the "License");
!  you may not use this file except in compliance with the License.
!  You may obtain a copy of the License at
!
!      http://www.apache.org/licenses/LICENSE-2.0
!
!  Unless required by applicable law or agreed to in writing, software
!  distributed under the License is distributed on an "AS IS" BASIS,
!  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
!  See the License for the specific language governing permissions and
!  limitations under the License.
!
module taylor_sub
  implicit none

contains

subroutine taylor(mg,system,info,stencil,srg,tspsi_in,tspsi_out,sshtpsi,   &
                  ppg,V_local,rt)
  use inputoutput, only: n_hamil
  use structures
  use rt_step_recovery,only:recovery_wave
#ifdef USE_HSE
  use exx_native,only:exx_recovery_status
#endif
  use hamiltonian, only: hpsi
  use sendrecv_grid, only: s_sendrecv_grid
  use nvtx_wrapper
  implicit none
  type(s_rgrid),intent(in) :: mg
  type(s_dft_system),intent(in) :: system
  type(s_parallel_info),intent(in) :: info
  type(s_stencil),intent(in) :: stencil
  type(s_sendrecv_grid),intent(inout) :: srg
  type(s_orbital),intent(inout) :: tspsi_in
  type(s_orbital),intent(inout) :: tspsi_out
  type(s_orbital),intent(inout) :: sshtpsi
  type(s_pp_grid),intent(in) :: ppg
  type(s_scalar) ,intent(in) :: V_local(system%nspin)
  type(s_rt),     intent(inout) :: rt
  integer :: nn,ix,iy,iz
  integer :: ik,io,is,nspin
  call nvtxStartRange('taylor', __LINE__)

  nspin = system%nspin

  do nn=1,n_hamil
    if(mod(nn,2)==1)then
      call hpsi(tspsi_in,sshtpsi,info,mg,V_local,system,stencil,srg,ppg)
      if(rt%recover_errors)then
#ifdef USE_HSE
        rt%step_error=max(rt%step_error,exx_recovery_status(system))
#endif
        call recovery_wave(mg,info,sshtpsi,rt%step_error)
        if(rt%step_error/=0)then
          call nvtxEndRange
          return
        endif
      endif
      if (nn==1) then
#ifdef USE_OPENACC
!$acc kernels
!$acc loop collapse(6) private(ik,io,is,iz,iy,ix)
#else
!$OMP parallel do collapse(5) private(ik,io,is,iz,iy,ix)
#endif
        do ik=info%ik_s,info%ik_e
        do io=info%io_s,info%io_e
          do is=1,nspin
            do iz=mg%is(3),mg%ie(3)
            do iy=mg%is(2),mg%ie(2)
            do ix=mg%is(1),mg%ie(1)
              tspsi_out%zwf(ix,iy,iz,is,io,ik,1)=tspsi_in%zwf(ix,iy,iz,is,io,ik,1)+ &
                                                   rt%zc(nn)*sshtpsi%zwf(ix,iy,iz,is,io,ik,1)
            end do
            end do
            end do
          end do
        end do
        end do
#ifdef USE_OPENACC
!$acc end kernels
#endif
      else
#ifdef USE_OPENACC
!$acc parallel loop collapse(6) private(ik,io,is,iz,iy,ix)
#else
!$OMP parallel do collapse(5) private(ik,io,is,iz,iy,ix)
#endif
        do ik=info%ik_s,info%ik_e
        do io=info%io_s,info%io_e
          do is=1,nspin
            do iz=mg%is(3),mg%ie(3)
            do iy=mg%is(2),mg%ie(2)
            do ix=mg%is(1),mg%ie(1)
              tspsi_out%zwf(ix,iy,iz,is,io,ik,1)=tspsi_out%zwf(ix,iy,iz,is,io,ik,1)+ &
                                                   rt%zc(nn)*sshtpsi%zwf(ix,iy,iz,is,io,ik,1)
            end do
            end do
            end do
          end do
        end do
        end do
#ifdef USE_OPENACC
!$acc end parallel
#endif
      end if
    else
      call hpsi(sshtpsi,tspsi_in,info,mg,V_local,system,stencil,srg,ppg)
      if(rt%recover_errors)then
#ifdef USE_HSE
        rt%step_error=max(rt%step_error,exx_recovery_status(system))
#endif
        call recovery_wave(mg,info,tspsi_in,rt%step_error)
        if(rt%step_error/=0)then
          call nvtxEndRange
          return
        endif
      endif
#ifdef USE_OPENACC
!$acc parallel loop collapse(6) private(ik,io,is,iz,iy,ix)
#else
!$OMP parallel do collapse(5) private(ik,io,is,iz,iy,ix)
#endif
      do ik=info%ik_s,info%ik_e
      do io=info%io_s,info%io_e
        do is=1,nspin
          do iz=mg%is(3),mg%ie(3)
          do iy=mg%is(2),mg%ie(2)
          do ix=mg%is(1),mg%ie(1)
            tspsi_out%zwf(ix,iy,iz,is,io,ik,1)=tspsi_out%zwf(ix,iy,iz,is,io,ik,1)+ &
                                               rt%zc(nn)*tspsi_in%zwf(ix,iy,iz,is,io,ik,1)
          end do
          end do
          end do
        end do
      end do
      end do
#ifdef USE_OPENACC
!$acc end parallel
#endif
    end if
  end do

  call nvtxEndRange
end subroutine taylor

end module taylor_sub


!
!  Copyright 2019-2024 SALMON developers
!
!  Licensed under the Apache License, Version 2.0 (the "License");
!  you may not use this file except in compliance with the License.
!  You may obtain a copy of the License at
!
!      http://www.apache.org/licenses/LICENSE-2.0
!
!  Unless required by applicable law or agreed to in writing, software
!  distributed under the License is distributed on an "AS IS" BASIS,
!  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
!  See the License for the specific language governing permissions and
!  limitations under the License.
!
!--------10--------20--------30--------40--------50--------60--------70--------80--------90--------100-------110-------120-------130
#include "config.h"
module dcdft
  implicit none
contains

  subroutine init_dcdft(dc,pp,mixing,ewald)
    use structures
    use salmon_global, only: nproc_k, nproc_ob, nproc_rgrid, nproc_rgrid_tot &
    & , nstate, nelec, yn_dc, nstate_frag, temperature, xc, num_fragment
    use exx_functional, only: is_hybrid
    implicit none
    type(s_dcdft)        ,intent(inout) :: dc
    type(s_pp_info)      ,intent(inout) :: pp
    type(s_mixing)       ,intent(inout) :: mixing
    type(s_ewald_ion_ion),intent(inout) :: ewald
    !
    integer :: nproc_k_tmp,nproc_ob_tmp, nproc_rgrid_tmp(3)

    call check_dcdft_complex_options
    ! Catch impossible capacity before fragment initialization fills occupations.
    if(temperature>0d0.and.(is_hybrid(xc)))then
      if(2d0*dble(nstate_frag)*dble(product(num_fragment))<dble(nelec)) &
        error stop 'DC thermal occupations: insufficient weighted state capacity; increase nstate_frag'
    endif
    
    nproc_k_tmp = nproc_k
    nproc_ob_tmp = nproc_ob
    nproc_rgrid_tmp = nproc_rgrid
    dc%nstate_tot = nstate
    dc%nstate_frag = nstate_frag
    
  ! total system
    nproc_k = 1 ! total system owns the complete k-point list
    nproc_ob = 1 ! override
    nproc_rgrid = nproc_rgrid_tot ! override
    yn_dc = 't' ! override !!!!!! future work: remove
    call init_total
    
  ! fragment
    nproc_k = nproc_k_tmp ! override
    nproc_ob = nproc_ob_tmp ! override
    nproc_rgrid = nproc_rgrid_tmp ! override
    nstate = dc%nstate_frag ! override
    yn_dc = 'y' ! override !!!!!! future work: remove
    call init_comm_frag
    call init_fragment
    
  contains

    subroutine init_total
      use parallelization, only: nproc_group_global, nproc_id_global, nproc_size_global
      use initialization_sub, only: init_dft, init_nion_div
      use sendrecv_grid, only: dealloc_cache
      use mixing_sub, only: init_mixing
      use salmon_pp, only: read_pslfile
      use prep_pp_sub, only: init_ps
      use salmon_global, only: num_fragment, nelec, base_directory, method_init_density
      use filesystem, only: atomic_create_directory
      use read_gs, only: read_dns_cube
      use Total_Energy, only: init_ewald
      implicit none
      integer :: i
      type(s_stencil) :: stencil_dummy
      type(s_sendrecv_grid) :: srg_dummy
      type(s_ofile) :: ofile_dummy
      type(s_unfold) :: unfold_dummy
      
    ! MPI for the total system
      dc%icomm_tot = nproc_group_global
      dc%id_tot = nproc_id_global
      dc%isize_tot = nproc_size_global
      
    ! base_directory for the total system
      if(base_directory /= './') stop "DC method (yn_dc=y): base_directory must be default."
      dc%base_directory = './data_dcdft/total/'
      call atomic_create_directory(dc%base_directory,dc%icomm_tot,dc%id_tot)
      base_directory = dc%base_directory ! override
    
      dc%n_frag = num_fragment(1)*num_fragment(2)*num_fragment(3) ! # of the fragments
      dc%elec_num_tot = dble(nelec) ! # of total electrons
     
    ! initialization for the total system
      call init_dft(dc%icomm_tot,dc%info_tot,dc%lg_tot,dc%mg_tot,dc%system_tot, &
      & stencil_dummy,dc%fg_tot,dc%poisson_tot,srg_dummy,dc%srg_scalar_tot,ofile_dummy,unfold_dummy)
      deallocate(dc%system_tot%rocc)
      call dealloc_cache(srg_dummy)
      
      call allocate_scalar(dc%mg_tot,dc%rho_tot)
      call allocate_scalar(dc%mg_tot,dc%vh_tot)
      call allocate_scalar(dc%mg_tot,dc%vpsl_tot)
      allocate(dc%rho_tot_s(dc%system_tot%nspin),dc%vloc_tot(dc%system_tot%nspin),dc%vxc_tot(dc%system_tot%nspin))
      do i=1,dc%system_tot%nspin
        call allocate_scalar(dc%mg_tot,dc%rho_tot_s(i))
        call allocate_scalar(dc%mg_tot,dc%vloc_tot(i))
        call allocate_scalar(dc%mg_tot,dc%vxc_tot(i))
      end do
      
    ! mixing
      mixing%num_rho_stock = 21
      call init_mixing(dc%system_tot%nspin,dc%mg_tot,mixing)
      
    ! Vpsl
      call read_pslfile(dc%system_tot,pp)
      call init_ps(dc%lg_tot,dc%mg_tot,dc%system_tot,dc%info_tot,dc%fg_tot,dc%poisson_tot, &
      & pp,dc%ppg_tot,dc%vpsl_tot)
      
      if(method_init_density=='read_dns_cube') then
      ! read the initial density for the total system
        call read_dns_cube(dc%lg_tot,dc%mg_tot,dc%system_tot,dc%info_tot,dc%rho_tot,dc%rho_tot_s)
      end if
      
    ! Ewald
      call init_nion_div(dc%system_tot,dc%lg_tot,dc%mg_tot,dc%info_tot)
      call init_ewald(dc%system_tot,dc%info_tot,ewald)
    
    end subroutine init_total

    subroutine init_comm_frag
      use parallelization, only: nproc_group_global, nproc_id_global, nproc_size_global
      use communication, only: comm_create_group,comm_get_groupinfo
      use filesystem, only: atomic_create_directory
      use salmon_global, only: base_directory
      implicit none
      integer :: icomm_frag,isize_frag,id_frag
      integer :: npg,i,j,k,m
      
    ! set dc%i_frag (fragment index)
      npg = dc%isize_tot / dc%n_frag
      m = mod(dc%isize_tot,dc%n_frag) ! nproc = npg*dc%n_frag + m
      k=0
      do j=0,dc%n_frag-1
      do i=0,npg-1
        if(j*npg+i==dc%id_tot) then
          dc%i_frag=j
          k=1
          exit
          exit
        end if
      end do
      end do
      if(k==0) dc%i_frag = dc%id_tot-npg*dc%n_frag
      dc%i_frag = dc%i_frag + 1 ! = 1:dc%n_frag
      
    ! split communicator
      icomm_frag = comm_create_group(dc%icomm_tot,dc%i_frag,dc%id_tot) ! dc%i_frag : color, dc%id_tot : key
      call comm_get_groupinfo(icomm_frag, id_frag, isize_frag)
      
    ! MPI for the fragment
      dc%icomm_frag = icomm_frag
      dc%id_frag = id_frag
      dc%isize_frag = isize_frag
      
    ! Override global variables
      nproc_group_global = icomm_frag
      nproc_id_global = id_frag
      nproc_size_global = isize_frag
      write(base_directory, '(a, i6.6, a)') './data_dcdft/fragments/', dc%i_frag, '/'
      
    ! base_directory for the fragment
      call atomic_create_directory(base_directory,icomm_frag,id_frag)
      
!write(*,'(a,5i10)') " i_frag,id_F,isize_F,id,isize",dc%i_frag,id_frag,isize_frag,dc%id_tot,dc%isize_tot
      
    end subroutine init_comm_frag
    
    subroutine init_fragment
      use salmon_global, only: num_rgrid_buffer, kion, rion, natom, num_rgrid, al, num_fragment, &
      & file_atom_coor_frag, yn_out_dc_fragment_coor
      implicit none
      integer :: i_frag,n,i,j,k,ii,jj,kk
      integer :: iatom,iatom_frag
      integer :: own_id(natom),own_image(3,natom)
      integer :: kion_frag(natom,dc%n_frag),natom_frag(dc%n_frag)
      real(8) :: dr
      real(8) :: r1(3),r2(3),r(3),boundary_tol(3)
      real(8) :: ldomain(3),lbuffer(3)
      real(8) :: rion_frag(3,natom,dc%n_frag)
    
    ! length of domain
      ldomain(1:3) = al(1:3) / dble(num_fragment(1:3))
      ! Use the same roundoff allowance on every fragment boundary, including
      ! periodic images. Treat near-boundary atoms as lying on the boundary:
      ! include the lower face and exclude the upper face. Do not move atoms.
      boundary_tol = 32d0 * epsilon(1d0) * al
      do n=1,3 ! x,y,z
      ! rion --> rion = [0:al] (total system)
        do i=1,natom
          rion(n,i) = r_periodic(rion(n,i),al(n))
          if(rion(n,i) < 0d0 .or. rion(n,i) > al(n)) stop "DC method (yn_dc=y): rion"
        end do
      ! dc%nxyz_domain: # of grid points for each domain
      ! dc%nxyz_buffer: # of grid points for the buffer region
        if(mod(num_rgrid(n),num_fragment(n))==0) then
          dc%nxyz_domain(n) = num_rgrid(n) / num_fragment(n)
          dc%nxyz_buffer(n) = num_rgrid_buffer(n)
          dr = al(n)/dble(num_rgrid(n))
          lbuffer(n) = dr * dc%nxyz_buffer(n) ! length of the buffer region
        else
          stop "DC method (yn_dc=y): mod(num_rgrid,num_fragment) /= 0"
        end if
      end do ! n=x,y,z

    ! position of each fragment
      allocate(dc%ixyz_frag(3,dc%n_frag),dc%rxyz_frag(3,dc%n_frag))
      i_frag = 1
      do i=1,num_fragment(1)
      do j=1,num_fragment(2)
      do k=1,num_fragment(3)
      ! ix_total = ix_fragment + dc%ixyz_frag(1,dc%i_frag), ix_fragment=[1:dc%nxyz_domain(1)], etc.
        dc%ixyz_frag(1,i_frag) = (i-1)*dc%nxyz_domain(1)
        dc%ixyz_frag(2,i_frag) = (j-1)*dc%nxyz_domain(2)
        dc%ixyz_frag(3,i_frag) = (k-1)*dc%nxyz_domain(3)
        dc%rxyz_frag(1,i_frag) = dble(i-1)*ldomain(1)
        dc%rxyz_frag(2,i_frag) = dble(j-1)*ldomain(2)
        dc%rxyz_frag(3,i_frag) = dble(k-1)*ldomain(3)
        i_frag = i_frag + 1
      end do
      end do
      end do
      
    ! variables for each fragment
      i_frag = 1
      do i=1,num_fragment(1)
      do j=1,num_fragment(2)
      do k=1,num_fragment(3)
      ! boundaries of the fragment i_frag
        r1 = dc%rxyz_frag(:,i_frag) - lbuffer
        r2 = dc%rxyz_frag(:,i_frag) + ldomain + lbuffer
      ! atom count
        iatom_frag = 0
        do iatom=1,natom
          do ii=-1,1
          do jj=-1,1
          do kk=-1,1
            r(1:3) = rion(1:3,iatom) ! r = [0:al]
            r(1) = r(1) + dble(ii)*al(1)
            r(2) = r(2) + dble(jj)*al(2)
            r(3) = r(3) + dble(kk)*al(3)
            if( all(r1-boundary_tol <= r) .and. all(r < r2-boundary_tol) ) then
              iatom_frag = iatom_frag + 1
              if(iatom_frag>natom)error stop 'DC fragment atom image capacity exceeded'
              if(i_frag==dc%i_frag)then
                own_id(iatom_frag)=iatom
                own_image(:,iatom_frag)=[ii,jj,kk]
              endif
              rion_frag(1:3,iatom_frag,i_frag) = r(1:3) - dc%rxyz_frag(1:3,i_frag)
              kion_frag(iatom_frag,i_frag) = kion(iatom)
            end if
          end do
          end do
          end do
        end do
        natom_frag(i_frag) = iatom_frag
        i_frag = i_frag + 1
      end do
      end do
      end do
    ! Preserve global identity before global atom arrays become fragment arrays.
      if(file_atom_coor_frag=='none')then
        allocate(dc%atom_global(natom_frag(dc%i_frag)),dc%atom_image(3,natom_frag(dc%i_frag)))
        dc%atom_global=own_id(:natom_frag(dc%i_frag))
        dc%atom_image=own_image(:,:natom_frag(dc%i_frag))
      endif
    ! set variables for own fragment
    
    ! nelec (total system) --> nelec (fragment)
      nelec = nelec * natom_frag(dc%i_frag) / natom ! initial guess
    
    ! al, num_rgrid (total system) --> al, num_rgrid (fragment)
      al = ldomain + 2d0*lbuffer
      num_rgrid = dc%nxyz_domain + 2*dc%nxyz_buffer
      
    ! natom, rion, kion (total system) --> natom, rion, kion (fragment)
      natom = natom_frag(dc%i_frag)
      deallocate(rion,kion)
      allocate(rion(3,natom),kion(natom))
      rion(1:3,1:natom) = rion_frag(1:3,1:natom,dc%i_frag)
      kion(1:natom) = kion_frag(1:natom,dc%i_frag)
      do i=1,natom
        do n=1,3 ! x,y,z
          rion(n,i) = r_periodic(rion(n,i),al(n))
        end do
      end do
      
      if(file_atom_coor_frag /= 'none') call read_atom_frag ! read & override natom, rion, kion (fragment)
      if(yn_out_dc_fragment_coor == 'y') call write_atom_frag
      
    ! dc%jxyz_tot: r-grid (fragment) --> r-grid (total)
      allocate(dc%jxyz_tot(maxval(num_rgrid),3))
      do n=1,3 ! x,y,z
        do i=1,num_rgrid(n) ! r-grid (fragment)
          if(i <= dc%nxyz_domain(n) + dc%nxyz_buffer(n)) then
            j = dc%ixyz_frag(n,dc%i_frag) + i
          else
            j = dc%ixyz_frag(n,dc%i_frag) + ( i - num_rgrid(n) ) ! minus region
          end if
          j = mod(j+dc%lg_tot%num(n)-1,dc%lg_tot%num(n))+1
          dc%jxyz_tot(i,n) = j ! r-grid (total)
        end do
      end do
      
      if(dc%id_frag==0) then
        write(*,'(a,6i10)') "fragment, natom, nelec, ixyz_frag: ",dc%i_frag, natom, nelec, dc%ixyz_frag(1:3,dc%i_frag)
      end if

    end subroutine init_fragment

    subroutine write_atom_frag
      use salmon_global, only: base_directory, kion, natom, rion
      use inputoutput, only: ulength_from_au
      use communication, only: comm_is_root, comm_sync_all
      use filesystem, only: atomic_create_directory, get_filehandle
      implicit none
      integer :: ia, iu
      character(256) :: directory, filename

      directory = trim(base_directory)//'data_for_restart/'
      call atomic_create_directory(directory, dc%icomm_frag, dc%id_frag)
      if(comm_is_root(dc%id_frag)) then
        filename = trim(directory)//'atomic_coor.txt'
        iu = get_filehandle()
        open(iu, file=filename, status='replace')
        do ia = 1,natom
          write(iu,1000) trim(pp%atom_symbol(kion(ia))), rion(1:3,ia)*ulength_from_au, kion(ia)
        end do
        close(iu)
      end if
      call comm_sync_all(dc%icomm_frag)

1000  format("'",a,"'  ",3f24.18,i4)
    end subroutine write_atom_frag
    
    function r_periodic(r,a) ! r --> r_periodic in [0,a]
      implicit none
      real(8) :: r_periodic
      real(8),intent(in) :: r,a
      r_periodic = r
      do while (r_periodic < 0d0)
        r_periodic = r_periodic + a
      end do
      do while (r_periodic > a)
        r_periodic = r_periodic - a
      end do
    end function r_periodic
    
    subroutine read_atom_frag
      use salmon_global, only: natom, kion, Rion, file_atom_coor_frag, base_directory
      use inputoutput, only: ulength_to_au
      use communication, only: comm_is_root, comm_bcast
      implicit none
      integer :: iu=123, ia, counter
      character(256) :: filename,cbuf
      
      filename = trim(base_directory)//trim(file_atom_coor_frag)
      
      if(comm_is_root(dc%id_frag)) then
        open(iu, file=filename, status="old")
        counter = 0
        do
          read(iu,'()',end=100)
          counter = counter + 1
        end do
100 close(iu)
        natom = counter
      end if
      call comm_bcast(natom,dc%icomm_frag)

      deallocate(rion,kion)
      allocate(rion(3,natom),kion(natom))
      
      if(comm_is_root(dc%id_frag)) then
        open(iu, file=filename, status="old")
        rewind(iu)
        do ia = 1,natom
          read(iu,*) cbuf, Rion(1:3,ia), kion(ia)
        enddo
        close(iu)
        rion = rion * ulength_to_au
        write(*,*) "read atomic coordinates from ",filename
      end if

      call comm_bcast(Rion,dc%icomm_frag)
      call comm_bcast(kion,dc%icomm_frag)
      
    end subroutine read_atom_frag

    subroutine check_dcdft_complex_options
      use plusU_global, only: PLUS_U_ON
      use salmon_global, only: num_kgrid, temperature, yn_spinorbit
      use ieee_finite_check, only: ieee_is_finite => is_finite
      implicit none
      logical :: complex_path

      complex_path = product(num_kgrid) > 1
      if (.not.complex_path) return
      if (.not.ieee_is_finite(temperature) .or. temperature < 0d0) &
        stop "DC complex k-point path: temperature must be non-negative and finite."
      if (yn_spinorbit == 'y') &
        stop "DC complex k-point path: spin-orbit and noncollinear calculations are unsupported."
      if (PLUS_U_ON) stop "DC complex k-point path: DFT+U is unsupported."
    end subroutine check_dcdft_complex_options

  end subroutine init_dcdft
  
!===================================================================================================================================
  
  ! rho_s (fragment) --> dc%rho_tot_s (total system)
  subroutine calc_rho_total_dcdft(nspin,lg,mg,info,rho_s,dc)
    use structures
    use communication, only: comm_summation
    implicit none
    integer,              intent(in) :: nspin
    type(s_rgrid),        intent(in) :: lg,mg
    type(s_parallel_info),intent(in) :: info
    type(s_scalar),       intent(in) :: rho_s(nspin)
    type(s_dcdft)                    :: dc
    !
    integer :: ix,iy,iz,ispin,ix_tot,iy_tot,iz_tot
    real(8),dimension(lg%num(1),lg%num(2),lg%num(3),nspin) :: frg_tmp,frg
    real(8),dimension(dc%lg_tot%num(1),dc%lg_tot%num(2),dc%lg_tot%num(3),nspin) :: tot_tmp,tot
    
  ! rho_s (fragment)
    frg_tmp = 0d0
    do ispin=1,nspin
    do iz=mg%is(3),mg%ie(3)
    do iy=mg%is(2),mg%ie(2)
    do ix=mg%is(1),mg%ie(1)
      frg_tmp(ix,iy,iz,ispin) = rho_s(ispin)%f(ix,iy,iz)
    end do
    end do
    end do
    end do
    call comm_summation(frg_tmp,frg,lg%num(1)*lg%num(2)*lg%num(3)*nspin,info%icomm_r)
    
  ! rho_s (total)
    tot_tmp = 0d0
    if(info%id_rko==0) then ! info%id_rko == 0 : representative process of each fragment
      do ispin=1,nspin
      do iz=1,dc%nxyz_domain(3); iz_tot = dc%jxyz_tot(iz,3)
      do iy=1,dc%nxyz_domain(2); iy_tot = dc%jxyz_tot(iy,2)
      do ix=1,dc%nxyz_domain(1); ix_tot = dc%jxyz_tot(ix,1)
        tot_tmp(ix_tot,iy_tot,iz_tot,ispin) = frg(ix,iy,iz,ispin)
      end do
      end do
      end do
      end do
    end if
    call comm_summation(tot_tmp,tot,dc%lg_tot%num(1)*dc%lg_tot%num(2)*dc%lg_tot%num(3)*nspin,dc%icomm_tot)
    do ispin=1,nspin
    do iz=dc%mg_tot%is(3),dc%mg_tot%ie(3)
    do iy=dc%mg_tot%is(2),dc%mg_tot%ie(2)
    do ix=dc%mg_tot%is(1),dc%mg_tot%ie(1)
      dc%rho_tot_s(ispin)%f(ix,iy,iz) = tot(ix,iy,iz,ispin)
    end do
    end do
    end do
    end do

    if(dc%id_tot==0) then
      write(*,*) "integral(rho_tot)=",sum(tot)*dc%system_tot%hvol," Ne=",dc%elec_num_tot
    end if
    
  end subroutine calc_rho_total_dcdft
  
!===================================================================================================================================
  
  ! v_local (fragment) = vh (total) + vpsl (total) + vxc (fragment) + v_boundary (fragment)
  subroutine calc_vlocal_fragment_dcdft(system,mg,info,stencil,xc_func,srg_scalar,srg,rho_s, &
  & pp,ppn,spsi,Vxc,energy,dc,v_local)
    use structures
    use timer
    use salmon_global, only: xi_dc
    use communication, only: comm_summation
    use salmon_xc, only: exchange_correlation
    implicit none
    ! intent(inout): exchange_correlation leaves a meta-GGA's
    ! kinetic-energy-density derivative on system%xc_payload.
    type(s_dft_system),   intent(inout) :: system
    type(s_rgrid),        intent(in)    :: mg
    type(s_parallel_info),intent(in)    :: info
    type(s_stencil),      intent(in)    :: stencil
    type(s_xc_functional),intent(in)    :: xc_func
    type(s_pp_info),      intent(in)    :: pp
    type(s_pp_nlcc),      intent(in)    :: ppn
    type(s_orbital),      intent(inout) :: spsi
    type(s_sendrecv_grid),intent(inout) :: srg,srg_scalar
    type(s_scalar),       intent(in)    :: rho_s(system%nspin)
    type(s_scalar),       intent(inout) :: Vxc(system%nspin)
    type(s_dft_energy),   intent(inout) :: energy
    type(s_dcdft),        intent(inout) :: dc
    type(s_scalar)                      :: v_local(system%nspin)

    !
    integer :: ix,iy,iz,ispin,ix_tot,iy_tot,iz_tot
    real(8) :: sum_exc
    real(8),dimension(dc%lg_tot%num(1),dc%lg_tot%num(2),dc%lg_tot%num(3)) :: tot_tmp,tot
    
    call timer_begin(LOG_CALC_EXC_COR)
    call exchange_correlation(system,xc_func,mg,srg_scalar,srg,rho_s, &
    & pp,ppn,info,spsi,stencil,Vxc,energy%E_xc,v_local(1)) ! v_local(1)%f (working array) := eexc
    sum_exc = 0d0
    do iz=mg%is(3),min(mg%ie(3),dc%nxyz_domain(3)) ! core region only
    do iy=mg%is(2),min(mg%ie(2),dc%nxyz_domain(2)) ! core region only
    do ix=mg%is(1),min(mg%ie(1),dc%nxyz_domain(1)) ! core region only
      sum_exc = sum_exc + v_local(1)%f(ix,iy,iz) * system%hvol
    end do
    end do
    end do
    call comm_summation(sum_exc,energy%E_xc,info%icomm_r) ! within fragment
    sum_exc = 0d0
    if(info%id_rko==0) sum_exc = energy%E_xc ! info%id_rko == 0 : representative process of each fragment
    call comm_summation(sum_exc,energy%E_xc,dc%icomm_tot) ! total system

    call timer_end(LOG_CALC_EXC_COR)
    
  ! v_h + v_psl (total)
    tot_tmp = 0d0
    do iz=dc%mg_tot%is(3),dc%mg_tot%ie(3)
    do iy=dc%mg_tot%is(2),dc%mg_tot%ie(2)
    do ix=dc%mg_tot%is(1),dc%mg_tot%ie(1)
      tot_tmp(ix,iy,iz) = dc%vh_tot%f(ix,iy,iz) + dc%vpsl_tot%f(ix,iy,iz)
    end do
    end do
    end do
    call comm_summation(tot_tmp,tot,dc%lg_tot%num(1)*dc%lg_tot%num(2)*dc%lg_tot%num(3),dc%icomm_tot)
    
  ! v_local (fragment)
    do ispin=1,system%nspin
    do iz=mg%is(3),mg%ie(3) ; iz_tot = dc%jxyz_tot(iz,3)
    do iy=mg%is(2),mg%ie(2) ; iy_tot = dc%jxyz_tot(iy,2)
    do ix=mg%is(1),mg%ie(1) ; ix_tot = dc%jxyz_tot(ix,1)
      v_local(ispin)%f(ix,iy,iz) = tot(ix_tot,iy_tot,iz_tot) + Vxc(ispin)%f(ix,iy,iz)
    end do
    end do
    end do
    end do
    
    if(xi_dc > 0d0) then
    ! v_local (fragment) <-- v_local (fragment) + vboundary
      call add_vboundary
    end if
    
  contains

    subroutine add_vboundary
      implicit none
      real(8) :: coef
      coef = 1d0/xi_dc
      
      do ispin=1,system%nspin
        tot_tmp = 0d0
        do iz=dc%mg_tot%is(3),dc%mg_tot%ie(3)
        do iy=dc%mg_tot%is(2),dc%mg_tot%ie(2)
        do ix=dc%mg_tot%is(1),dc%mg_tot%ie(1)
          tot_tmp(ix,iy,iz) = dc%rho_tot_s(ispin)%f(ix,iy,iz) ! after mixing
        end do
        end do
        end do
        call comm_summation(tot_tmp,tot,dc%lg_tot%num(1)*dc%lg_tot%num(2)*dc%lg_tot%num(3),dc%icomm_tot)
        do iz=mg%is(3),mg%ie(3) ; iz_tot = dc%jxyz_tot(iz,3)
        do iy=mg%is(2),mg%ie(2) ; iy_tot = dc%jxyz_tot(iy,2)
        do ix=mg%is(1),mg%ie(1) ; ix_tot = dc%jxyz_tot(ix,1)
          v_local(ispin)%f(ix,iy,iz) = v_local(ispin)%f(ix,iy,iz) + &
          & coef* ( rho_s(ispin)%f(ix,iy,iz) - tot(ix_tot,iy_tot,iz_tot) ) ! vboundary
        end do
        end do
        end do
      end do
    
    end subroutine add_vboundary
    
  end subroutine calc_vlocal_fragment_dcdft
  
!===================================================================================================================================

! cf. src/gs/occupation.f90
  SUBROUTINE ne2mu_dcdft(mg,info,energy,spsi,dc,system)
    use structures
    use communication, only: comm_summation
    use salmon_global, only: temperature,xc
    use dc_thermal, only: solve_dc_thermal,dc_thermal_capacity
    use exx_functional, only: is_hybrid
    implicit none
    type(s_rgrid),        intent(in) :: mg
    type(s_parallel_info),intent(in) :: info
    type(s_dft_energy),   intent(in) :: energy
    type(s_orbital),      intent(in) :: spsi
    type(s_dcdft),        intent(in) :: dc
    type(s_dft_system),intent(inout) :: system
    !
    real(8) :: wspin,emax,emin,thermal_ts
    integer :: ik,thermal_status
    real(8) :: thermal_f(system%no*system%nk*system%nspin*dc%n_frag)
    real(8) :: ne_each(system%no,system%nk,system%nspin)
    real(8),dimension(system%no,system%nk,system%nspin,dc%n_frag) :: &
      rocc,esp,ne_frag_orb,wrk1,wrk2
    !
    if(system%nspin==1) then
      wspin = 2d0
    else if(system%nspin==2) then
      wspin = 1d0
    end if

    call calc_ne_each
    wrk1 = 0d0
    wrk2 = 0d0
    if(info%id_rko==0) then ! info%id_rko == 0 : representative process of each fragment
      wrk1(:,:,:,dc%i_frag) = energy%esp(:,:,:)
      wrk2(:,:,:,dc%i_frag) = ne_each(:,:,:)
    end if
    call comm_summation(wrk1,esp,system%no*system%nk*system%nspin*dc%n_frag,dc%icomm_tot)
    call comm_summation(wrk2,ne_frag_orb,system%no*system%nk*system%nspin*dc%n_frag,dc%icomm_tot)

    emin = minval(esp)
    emax = maxval(esp)
    ! Use the same charge-converged Fermi solver for all hybrid DC SCF.
    if(temperature>0d0.and.(is_hybrid(xc)))then
      wrk1=ne_frag_orb
      do ik=1,system%nk
        wrk1(:,ik,:,:)=wrk1(:,ik,:,:)*system%wtk(ik)
      enddo
      call solve_dc_thermal(reshape(esp,[size(esp)]),reshape(wrk1,[size(wrk1)]), &
        temperature,wspin,dc%elec_num_tot,system%mu,thermal_f,thermal_ts,thermal_status)
      ! All ranks hold identical global arrays and take the same failure path.
      if(thermal_status==dc_thermal_capacity) &
        error stop 'DC thermal occupations: insufficient weighted state capacity; increase nstate_frag'
      if(thermal_status/=0)error stop 'DC thermal occupations: invalid input or chemical potential not converged'
      rocc=wspin*reshape(thermal_f,shape(rocc))
    else
      call ne2mu_core(dc%elec_num_tot,emax,emin,system%mu)
    endif

    system%rocc(:,:,:) = rocc(:,:,:,dc%i_frag)

    return

  contains

    subroutine calc_ne_each
      implicit none
      integer :: io,ik,ispin,ix,iy,iz
      real(8) :: wrk(system%no,system%nk,system%nspin)

      wrk = 0d0
      if (allocated(spsi%rwf)) then
        do ispin=1,system%nspin
        do ik=info%ik_s,info%ik_e
        do io=info%io_s,info%io_e
          do iz=mg%is(3),min(mg%ie(3),dc%nxyz_domain(3)) ! core region only
          do iy=mg%is(2),min(mg%ie(2),dc%nxyz_domain(2)) ! core region only
          do ix=mg%is(1),min(mg%ie(1),dc%nxyz_domain(1)) ! core region only
            wrk(io,ik,ispin) = wrk(io,ik,ispin) + &
              spsi%rwf(ix,iy,iz,ispin,io,ik,1)**2 * system%hvol
          end do
          end do
          end do
        end do
        end do
        end do
      else
      do ispin=1,system%nspin
      do ik=info%ik_s,info%ik_e
      do io=info%io_s,info%io_e
        do iz=mg%is(3),min(mg%ie(3),dc%nxyz_domain(3)) ! core region only
        do iy=mg%is(2),min(mg%ie(2),dc%nxyz_domain(2)) ! core region only
        do ix=mg%is(1),min(mg%ie(1),dc%nxyz_domain(1)) ! core region only
          wrk(io,ik,ispin) = wrk(io,ik,ispin) + &
            abs(spsi%zwf(ix,iy,iz,ispin,io,ik,1))**2 * system%hvol
        end do
        end do
        end do
      end do
      end do
      end do
      end if
      call comm_summation(wrk,ne_each,system%no*system%nk*system%nspin,info%icomm_rko)
    end subroutine calc_ne_each

    SUBROUTINE mu2ne(muin,neout)
      use salmon_global, only: temperature, yn_spinorbit
      implicit none
      real(8), intent(in)  :: muin
      real(8), intent(out) :: neout
      integer :: i_frag,ispin,ik,io
      real(8) :: fact

      neout=0d0
      if(temperature==0d0) then
        do i_frag=1,dc%n_frag
        do ispin=1,system%nspin
        do ik=1,system%nk
        do io=1,system%no
          fact = esp(io,ik,ispin,i_frag) - muin
          if(fact > 0d0) then
            rocc(io,ik,ispin,i_frag) = 0d0
          else
            rocc(io,ik,ispin,i_frag) = wspin
          end if
          neout = neout + system%wtk(ik)*rocc(io,ik,ispin,i_frag) &
            * ne_frag_orb(io,ik,ispin,i_frag)
        end do
        end do
        end do
        end do
      else
        do i_frag=1,dc%n_frag
        do ispin=1,system%nspin
        do ik=1,system%nk
        do io=1,system%no
          fact = (esp(io,ik,ispin,i_frag)-muin)/temperature
          if(fact.ge.40.d0) then
            rocc(io,ik,ispin,i_frag) = 0d0
          else
            rocc(io,ik,ispin,i_frag) = wspin/( 1d0 + exp( fact ) )
          endif
          neout = neout + system%wtk(ik)*rocc(io,ik,ispin,i_frag) &
            * ne_frag_orb(io,ik,ispin,i_frag)
        end do
        end do
        end do
        end do
      end if

      if(yn_spinorbit=='y') then
        neout = neout*0.5d0 !!! For the SO mode, ispin=2 components are duplicate copy of jspin=1.
      end if
    END SUBROUTINE mu2ne

    subroutine ne2mu_core(nein,emax,emin,muout)
      implicit none
      real(8),intent(in)  :: nein,emax,emin
      real(8),intent(out) :: muout
      !
      integer :: iter,ii,p5,p1,p2,nc
      real(8) :: mu1,mu2,mu3,ne1,ne3,ne3o,diff_ne,diff_mu,muo,diff_ne2,wspin

      mu1 = emin
      mu2 = emax
      nc=0

      ITERATION: do iter=1,100000
        diff_ne = 100.d0
        diff_ne2 = 100.d0

        ne1  = 0d0
        ne3  = 0d0
        ne3o = 0d0

        diff_mu =100.d0
        muo=0.0d0

        call mu2ne(mu1,ne1)

        do ii=1,1000
          if ( ii .eq. 1000 ) then
            if ( nc .le. 50)  then
               nc= nc + 1
               mu1 = emin - 0.2d0*dble(nc)
               mu2 = emax + 0.2d0*dble(nc)
               cycle ITERATION
            else
               !print *,'=================================='
               !print *,'Const Ne does not converged!!!!!!!'
               !print *,'=================================='
               exit ITERATION
            endif
          endif
          if ( diff_ne < 1d-10  .and. diff_mu < 1d-9  &
             .and. diff_ne2 < 1.d-9 ) exit ITERATION
          mu3 = mu1 + (mu2-mu1)/2.d0
          ne3=0
          call mu2ne(mu3,ne3)
          diff_ne = abs((ne3-ne3o)/ne3)
          diff_ne2 = abs(nein-ne3)
          if ( (ne1-nein)*(ne3-nein) > 0 ) then
            mu1=mu3
            ne1=ne3
          else
            mu2=mu3
          end if

          ne3o = ne3
          diff_mu = mu3 - muo
          muo  = mu3
        end do
      end do ITERATION

      muout = mu3
      call mu2ne(muout,ne3)

    end subroutine ne2mu_core

  END SUBROUTINE ne2mu_dcdft
  
!===================================================================================================================================


!===================================================================================================================================

  subroutine calc_total_energy_dcdft(mg,system,info,stencil,srg,v_local,spsi,shpsi,sttpsi,ewald,pp,rion_update,dc,energy)
    use structures
    use communication, only: comm_summation
    use hamiltonian, only: add_xc_tau_operator
    use sendrecv_grid, only: update_overlap_real8, update_overlap_complex8
    use Total_Energy, only: calc_Total_Energy_periodic
#ifdef USE_HSE
    use exx_native, only: exx_enabled,exx_core_exchange,exx_set_phase,exx_pre_scf
#endif
    use salmon_global, only: kion !!!!!! future work: remove (kion --> system%kion)
    implicit none
    type(s_rgrid),        intent(in) :: mg
    type(s_dft_system),   intent(in) :: system
    type(s_parallel_info),intent(in) :: info
    type(s_stencil),      intent(in) :: stencil
    type(s_sendrecv_grid),intent(inout) :: srg
    type(s_scalar)       ,intent(in) :: v_local(system%nspin)
    ! intent(inout): the tau operator reads the orbital halo, which is refreshed here.
    type(s_orbital),      intent(inout) :: spsi
    type(s_orbital),      intent(in) :: shpsi,sttpsi
    type(s_ewald_ion_ion),intent(in) :: ewald
    type(s_pp_info)      ,intent(in) :: pp
    logical              ,intent(in) :: rion_update
    type(s_dcdft),        intent(inout) :: dc
    type(s_dft_energy)               :: energy
    !
    integer :: ispin,io,ik
    integer,dimension(3) :: is,ie
    real(8) :: E_tmp,E_local(2),E_sum(2),exchange_core,exchange_total
    type(s_orbital) :: staupsi

#ifdef USE_HSE
    call exx_set_phase(dc%system_tot,exx_pre_scf(system))
#endif
    is(1:3) = mg%is(1:3)
    ie(1:3) = min(mg%ie(1:3),dc%nxyz_domain(1:3)) ! core region only
    
    if (allocated(spsi%rwf)) then ! real wavefunctions

  ! kinetic energy (E_kin)
    E_tmp = 0d0
    do ispin=1,system%Nspin
    do io=info%io_s,info%io_e
      E_tmp = E_tmp + system%rocc(io,1,ispin) &
                  * sum(  spsi%rwf(is(1):ie(1),is(2):ie(2),is(3):ie(3),ispin,io,1,1) &
                      * sttpsi%rwf(is(1):ie(1),is(2):ie(2),is(3):ie(3),ispin,io,1,1) ) * system%Hvol
    end do
    end do
    E_local(1) = E_tmp

  ! nonlocal part (E_ion_nloc)
    E_tmp = 0d0
    do ispin=1,system%Nspin
    do io=info%io_s,info%io_e
      E_tmp = E_tmp + system%rocc(io,1,ispin) * system%hvol &
        * sum( spsi%rwf(is(1):ie(1),is(2):ie(2),is(3):ie(3),ispin,io,1,1) &
           * (shpsi%rwf(is(1):ie(1),is(2):ie(2),is(3):ie(3),ispin,io,1,1) &
          - (sttpsi%rwf(is(1):ie(1),is(2):ie(2),is(3):ie(3),ispin,io,1,1) &
     + V_local(ispin)%f(is(1):ie(1),is(2):ie(2),is(3):ie(3)) &
             * spsi%rwf(is(1):ie(1),is(2):ie(2),is(3):ie(3),ispin,io,1,1) &
            ) &
          ) &
        )
    end do
    end do
    E_local(2) = E_tmp

  ! meta-GGA: shpsi carries the tau operator, so the same core-region expectation
  ! that E_ion_nloc just picked up is formed on its own and taken back out.  The
  ! stencil crosses the core boundary, which a grid sum of vtau*tau_GI would miss.
    if (system%xc_payload%use_tau_operator) then
      if(info%if_divide_rspace) call update_overlap_real8(srg, mg, spsi%rwf)
      call allocate_orbital_real(system%nspin,mg,info,staupsi)
      call add_xc_tau_operator(staupsi,spsi,info,mg,system,stencil,srg)
      E_tmp = 0d0
      do ispin=1,system%Nspin
      do io=info%io_s,info%io_e
        E_tmp = E_tmp + system%rocc(io,1,ispin) &
                    * sum(    spsi%rwf(is(1):ie(1),is(2):ie(2),is(3):ie(3),ispin,io,1,1) &
                        * staupsi%rwf(is(1):ie(1),is(2):ie(2),is(3):ie(3),ispin,io,1,1) ) * system%Hvol
      end do
      end do
      E_local(2) = E_local(2) - E_tmp
      call deallocate_orbital(staupsi)
    end if

    else ! complex wavefunctions

      E_tmp = 0d0
      do ispin=1,system%nspin
      do ik=info%ik_s,info%ik_e
      do io=info%io_s,info%io_e
        E_tmp = E_tmp + system%rocc(io,ik,ispin)*system%wtk(ik)*system%hvol &
          * real(sum(conjg(spsi%zwf(is(1):ie(1),is(2):ie(2),is(3):ie(3),ispin,io,ik,1)) &
            * sttpsi%zwf(is(1):ie(1),is(2):ie(2),is(3):ie(3),ispin,io,ik,1)),kind=8)
      end do
      end do
      end do
      E_local(1) = E_tmp

      E_tmp = 0d0
      do ispin=1,system%nspin
      do ik=info%ik_s,info%ik_e
      do io=info%io_s,info%io_e
        E_tmp = E_tmp + system%rocc(io,ik,ispin)*system%wtk(ik)*system%hvol &
          * real(sum(conjg(spsi%zwf(is(1):ie(1),is(2):ie(2),is(3):ie(3),ispin,io,ik,1)) &
            * (shpsi%zwf(is(1):ie(1),is(2):ie(2),is(3):ie(3),ispin,io,ik,1) &
            - sttpsi%zwf(is(1):ie(1),is(2):ie(2),is(3):ie(3),ispin,io,ik,1) &
            - v_local(ispin)%f(is(1):ie(1),is(2):ie(2),is(3):ie(3)) &
            * spsi%zwf(is(1):ie(1),is(2):ie(2),is(3):ie(3),ispin,io,ik,1))),kind=8)
      end do
      end do
      end do
      E_local(2) = E_tmp

  ! meta-GGA: remove the core-region expectation value of the tau operator
  ! already contained in shpsi from the nonlocal-energy contribution.
      if (system%xc_payload%use_tau_operator) then
        if(info%if_divide_rspace) call update_overlap_complex8(srg, mg, spsi%zwf)
        call allocate_orbital_complex(system%nspin,mg,info,staupsi)
        call add_xc_tau_operator(staupsi,spsi,info,mg,system,stencil,srg)
        E_tmp = 0d0
        do ispin=1,system%nspin
        do ik=info%ik_s,info%ik_e
        do io=info%io_s,info%io_e
          E_tmp = E_tmp + system%rocc(io,ik,ispin)*system%wtk(ik)*system%hvol &
            * real(sum(conjg(spsi%zwf(is(1):ie(1),is(2):ie(2),is(3):ie(3),ispin,io,ik,1)) &
              * staupsi%zwf(is(1):ie(1),is(2):ie(2),is(3):ie(3),ispin,io,ik,1)),kind=8)
        end do
        end do
        end do
        E_local(2) = E_local(2) - E_tmp
        call deallocate_orbital(staupsi)
      end if

    end if

  ! summation in each fragment
    call comm_summation(E_local,E_sum,2,info%icomm_rko)

  ! summation over the total system
    E_local = 0d0
    if(info%id_rko == 0) E_local = E_sum ! info%id_rko == 0 : representative process of each fragment
    call comm_summation(E_local,E_sum,2,dc%icomm_tot)
      
    energy%E_kin = E_sum(1)
    energy%E_ion_nloc = E_sum(2)
#ifdef USE_HSE
    if(exx_enabled(system))then
      call exx_core_exchange(system,mg,info,spsi,dc%nxyz_domain,exchange_core)
      E_tmp=0d0
      if(info%id_rko==0)E_tmp=exchange_core
      call comm_summation(E_tmp,exchange_total,dc%icomm_tot)
      energy%E_ion_nloc=energy%E_ion_nloc-2d0*exchange_total
      energy%E_xc=energy%E_xc+exchange_total
      if(dc%id_tot==0)write(*,'(a,es24.15)')'DC_HSE_CORE exchange Ha = ',exchange_total
    endif
#endif
    
  ! override (fragment --> total)
    deallocate(kion)
    allocate(kion(dc%system_tot%nion))
    kion = dc%system_tot%kion
    
    call calc_Total_Energy_periodic(dc%mg_tot,ewald,dc%system_tot,dc%info_tot,pp,dc%ppg_tot &
      & ,dc%fg_tot,dc%poisson_tot,rion_update,energy)
      
  ! override (total --> fragment)
    deallocate(kion)
    allocate(kion(system%nion))
    kion = system%kion
    
  end subroutine calc_total_energy_dcdft

!===================================================================================================================================
  
  subroutine write_total_dcdft(system,dc)
    use structures
    use communication, only: comm_summation
    use salmon_global, only: natom, kion, rion, base_directory, yn_out_dns
    use writefield, only: write_dns
    implicit none
    type(s_dcdft) :: dc
    type(s_dft_system),intent(in) :: system
    !
    character(256) :: dir_tmp
    
  ! override (fragment --> total)
    natom = dc%system_tot%nion
    deallocate(kion,rion)
    allocate(kion(natom),rion(3,natom))
    kion = dc%system_tot%kion
    rion = dc%system_tot%rion
    dir_tmp = base_directory
    base_directory = dc%base_directory
    
    if(yn_out_dns =='y') call write_dns(dc%lg_tot,dc%mg_tot,dc%system_tot,dc%info_tot,dc%rho_tot_s)
    
  ! override (total --> fragment)
    natom = system%nion
    deallocate(kion,rion)
    allocate(kion(natom),rion(3,natom))
    kion = system%kion
    rion = system%rion
    base_directory = dir_tmp
    
  end subroutine write_total_dcdft
  
end module dcdft

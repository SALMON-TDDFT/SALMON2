set(SOURCES
    builtin_pz.f90
    builtin_pzm.f90
    builtin_pz_sp.f90
    builtin_pw.f90
    builtin_pw92.f90
    builtin_r2scan.f90
    builtin_tbmbj.f90
    exx_k_selection.f90
    exx_functional.f90
    exx_gs_metadata.f90
    salmon_xc.f90
   )

# The noncollinear density routine also imports the pure spin-rotation helper.
if(NOT USE_HSE)
  list(APPEND SOURCES exx_symmetry.f90)
endif()

if(USE_HSE AND USE_MPI)
  list(APPEND SOURCES exx_worker_layout.f90 exx_spinor_wave_fft.f90 exx_spinor_wave_workers.f90 exx_worker_service.f90)
endif()

if(USE_HSE)
  list(APPEND SOURCES
    exx_blas_threads.f90
    exx_sparse_orbitals.f90
    exx_k_backend.f90
    exx_k_cufft.f90
    exx_batch_backend.f90
    exx_cufft.f90
    exx_local_fft.f90
    exx_adaptive_support.f90
    exx_pair_candidates.f90
    exx_spatial_local.f90
    rvv10.f90
    fftw_blocks.f90
    rvv10_distributed.f90
    rvv10_native.f90
    rvv10_ffte.f
    exx_wannier_gauge.f90
    exx_wannier.f90
    exx_symmetry.f90
    exx_collinear_fft.f90
    exx_k_exchange.f90
    exx_fft_consensus.f90
    exx_spinor.f90
    exx_k_pairs.f90
    exx_k_orbits.f90
    exx_ace.f90
    exx_distributed_metric.f90
    exx_distributed_alignment.f90
    exx_orbitals.f90
    exx_distributed_gauge.f90
    hybrid_semilocal.f90
    exx_gamma_pairs.f90
    exx_spatial.f90
    exx_factor_history.f90
    exx_native.f90
    lcfo_wf_support.f90
  )
endif()

list_prepend(SOURCES ${CMAKE_CURRENT_SOURCE_DIR})
list(APPEND SALMON_SOURCES ${SOURCES})
set(SALMON_SOURCES ${SALMON_SOURCES} PARENT_SCOPE)

/*
 *  Copyright 2019-2020 SALMON developers
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
#ifndef SALMON_STENCIL_GLUE
#define SALMON_STENCIL_GLUE

#include "config.h"

/* currently Xeon CPUs and Xeon Phi are 64B cacheline. */
#ifndef CACHELINE_SIZE
# define CACHELINE_SIZE 64
#endif

#ifdef USE_OPT_SOFTWARE_PREFETCH
# define PREFETCH_L1(p, distance)  _mm_prefetch(((char const*)p) + distance, _MM_HINT_T0)
# define BUSY_PREFETCH_L1(p)       PREFETCH_L1(p, CACHELINE_SIZE)
#else
# define PREFETCH_L1(p, distance)
# define BUSY_PREFETCH_L1(p)
#endif

#if defined(__KNC__) || defined(__AVX512F__)
# define MEM_ALIGNED 64
# define VECTOR_SIZE 4
#else
# define MEM_ALIGNED 32
# define VECTOR_SIZE 2
#endif

#ifdef USE_OPT_DOMAIN_IS_POW2
# ifdef ENABLE_STENCIL_CODE_WITH_PADDING
#   define IDX(npt) ((ix - ((ix + (npt) + NLx) & (NLx-1))) * PNLy * PNLz)
#   define IDY(npt) ((iy - ((iy + (npt) + NLy) & (NLy-1))) * PNLz)
#   define IDZ(npt) ((iz - ((iz + (npt) + NLz) & (NLz-1))))
# else
#   define IDX(npt) ((ix - ((ix + (npt) + NLx) & (NLx-1))) * NLy * NLz)
#   define IDY(npt) ((iy - ((iy + (npt) + NLy) & (NLy-1))) * NLz)
#   define IDZ(npt) ((iz - ((iz + (npt) + NLz) & (NLz-1))))
# endif
#else
# ifdef ENABLE_STENCIL_CODE_WITH_PADDING
#   define IDX(npt) ((ix - modx[ix + (npt) + NLx]) * PNLy * PNLz)
#   define IDY(npt) ((iy - mody[iy + (npt) + NLy]) * PNLz)
#   define IDZ(npt) ((iz - modz[iz + (npt) + NLz]))
# else
#   define IDX(npt) ((ix - modx[ix + (npt) + NLx]) * NLy * NLz)
#   define IDY(npt) ((iy - mody[iy + (npt) + NLy]) * NLz)
#   define IDZ(npt) ((iz - modz[iz + (npt) + NLz]))
# endif
#endif /* USE_OPT_DOMAIN_IS_POW2 */

#define MIN(n,m) (n < m ? n : m)

#include <immintrin.h>


#if defined(__AVX512F__) || (__KNC__)
// These load functions are general enough for both AVX512F and KNC
inline
__m512i _mm512_load_prefetch_epi64(void const* c) {
  __m512i a = _mm512_load_epi64(c);
  BUSY_PREFETCH_L1(c);
  return a;
}

inline
__m512d _mm512_load_prefetch_pd(void const* c) {
  __m512d a = _mm512_load_pd(c);
  BUSY_PREFETCH_L1(c);
  return a;
}
// NOTE: The original dcomplex_get_index and dcomplex_gather that were here
// used KNC-specific intrinsics. They are now moved/specialized below.
#endif


#if defined(__AVX512F__)

// AVX-512F specific implementation for gathering complex numbers
// Helper function dcomplex_get_indices_for_gather_avx512f (as defined before)
inline __m256i dcomplex_get_indices_for_gather_avx512f(__m128i complex_indices_m128) {
    // Multiply complex indices by 2 to get base double index for the real part
    __m128i real_part_base_indices = _mm_slli_epi32(complex_indices_m128, 1);

    // Create indices for imaginary parts (base double index + 1)
    __m128i ones_m128 = _mm_set1_epi32(1);
    __m128i imag_part_indices = _mm_add_epi32(real_part_base_indices, ones_m128);

    // Zero-extend the 128-bit index vectors to 256-bit vectors to prepare for interleaving
    __m256i real_indices_for_interleave = _mm256_zextsi128_si256(real_part_base_indices);
    __m256i imag_indices_for_interleave = _mm256_zextsi128_si256(imag_part_indices);
    
    return _mm256_unpacklo_epi32(real_indices_for_interleave, imag_indices_for_interleave);
}

// dcomplex_gather for AVX-512F
inline __m512d dcomplex_gather(void const* base_addr, __m512i complex_indices_in_m512i) {
    // Assume the input __m512i holds the four 32-bit complex indices in its lowest 128 bits.
    __m128i complex_indices_m128 = _mm512_castsi512_si128(complex_indices_in_m512i);

    // Generate the 8x32-bit indices for the individual double components.
    __m256i final_double_indices = dcomplex_get_indices_for_gather_avx512f(complex_indices_m128);
    
    // MODIFICATION: Use the integer literal 8 directly for the scale factor.
    return _mm512_i32gather_pd(final_double_indices, base_addr, 8); 
}

# include "./imci2avx512f.h" // This file provides other AVX-512F helpers

#elif defined(__KNC__)

/* Knights Corner specific implementations */

// Original dcomplex_get_index, now specific to KNC context
inline __m512i dcomplex_get_index_knc(__m512i idx) {
  const __m512i perm = _mm512_set_epi32(7, 7, 6, 6, 5, 5, 4, 4, 3, 3, 2, 2, 1, 1, 0, 0);
  const __m512i one  = _mm512_set4_epi32(1, 0, 1, 0);
  __m512i x = _mm512_permutevar_epi32(perm, idx);
  __m512i y = _mm512_slli_epi32(x, 1);  /* x * 2 */
  return      _mm512_xor_si512(y, one); /* y + 1 or y + 0 */
}

// Original dcomplex_gather, now specific to KNC context
inline __m512d dcomplex_gather(void const* m, __m512i idx) {
  const __m512i gidx = dcomplex_get_index_knc(idx); // Uses KNC helper
  return _mm512_i32loextgather_pd(gidx, m, _MM_UPCONV_PD_NONE, 8, _MM_HINT_NONE);
}

// KNC specific versions of other functions (originally from this block)
inline
__m512i _mm512_loadu_prefetch_epi32(int const* v) {
  __m512i w;
  w = _mm512_loadunpacklo_epi32(w, v + 0);
  w = _mm512_loadunpackhi_epi32(w, v + 16);
  BUSY_PREFETCH_L1(v);
  return w;
}

inline
__m512d dcast_to_dcmplx(double const *v) {
  const __m512i perm = _mm512_set_epi32(7, 6, 7, 6, 5, 4, 5, 4, 3, 2, 3, 2, 1, 0, 1, 0);
  __m512d w = _mm512_loadunpacklo_pd(_mm512_setzero_pd(), v);
  BUSY_PREFETCH_L1(v);
  return (__m512d) _mm512_permutevar_epi32(perm, (__m512i) w);
}

inline
__m512d dcomplex_mul(__m512d a, __m512d b) {
  __m512d ze = _mm512_setzero_pd();
  __m512d s0 = _mm512_swizzle_pd(a, _MM_SWIZ_REG_CDAB);  /* s0 = [a.i a.r] */
  __m512d re = _mm512_mask_blend_pd(0xAA, a, s0);        /* re = [a.r a.r] */
  __m512d im = _mm512_mask_sub_pd(a, 0x55, ze, s0);      /* im = [-a.i a.i] */
  __m512d t0 = _mm512_mul_pd(re, b);                     /* t0 = [a.r*b.r a.r*b.i] */
  __m512d s1 = _mm512_swizzle_pd(b, _MM_SWIZ_REG_CDAB);  /* s1 = [b.i b.r] */
  return       _mm512_fmadd_pd(im, s1, t0);              /* [-a.i*b.i+a.r*b.r a.i*b.r+a.r*b.i] */
}

#elif defined(__AVX__)
/* Sandy-Bridge or higher processors */
// This block was already present and remains unchanged.
inline
__m256d dcast_to_dcmplx(double const *v) {
  __m256d a = _mm256_loadu_pd(v);
  __m256d b = _mm256_permute2f128_pd(a, a, 0x0);
  return _mm256_shuffle_pd(b, b, 0xC);
}
#endif

#endif /* SALMON_STENCIL_GLUE */

#include "config.h"
! SALMON adapter: initial certified layout is complete grid/orbitals per rank,
! distributed k points. Exchange transfers density tiles; ACE applications stay local.
module hse_native
  use iso_fortran_env, only: int64
  use ieee_finite_check, only: ieee_is_finite => is_finite
  use structures
  use plusU_global, only: PLUS_U_ON
  use hse_exchange
  use hse_ace
  use hse_symmetry
  use sym_sub, only: use_symmetry,SymMatA,SymMatB
  use communication, only: comm_summation,comm_alltoall
  use salmon_global, only: xc,yn_periodic,yn_spinorbit,yn_jm,yn_dc,yn_md,yn_symmetrized_stencil,propagator,num_kgrid,hse_omega
  implicit none
  private
  public :: hse_enabled,hse_refresh,hse_add_action,hse_exchange_energy,hse_freeze
  public :: hse_pack,hse_unpack,hse_timings,hse_walltime
  public :: hse_taylor_stage
  type(hse_symmetry_map),save :: symmetry_map
  type(hse_kernel),save :: kernel
  type(hse_ace_state),save :: ace
  type(hse_ace_state),save :: initial_ace,midpoint_ace
  logical,save :: taylor_active=.false.,taylor_midpoint=.false.
  complex(8),allocatable,save :: cached_source(:,:,:),target_work(:,:,:),action_work(:,:,:),output_work(:,:,:)
  real(8),save :: hse_exchange_energy=0d0
  real(8),save :: hse_timings(4)=0d0 ! full EXX, ACE build, ACE apply, EXX collectives
  logical,save :: hse_freeze=.false.,reported_team=.false.,timing_enabled=.false.
contains
  subroutine hse_taylor_stage(stage)
    integer,intent(in) :: stage
    integer :: ierr
    select case(stage)
    case(0)
      taylor_active=.true.;taylor_midpoint=.false.
      initial_ace=ace
    case(1)
      call hse_ace_average(initial_ace,ace,midpoint_ace,ierr)
      if(ierr/=0)error stop 'HSE Taylor midpoint ACE failed'
      taylor_midpoint=.true.
    case(2)
      taylor_active=.false.;taylor_midpoint=.false.
      if(allocated(initial_ace%factors))deallocate(initial_ace%factors)
      if(allocated(midpoint_ace%factors))deallocate(midpoint_ace%factors)
    case default
      error stop 'Invalid HSE Taylor stage'
    end select
  end subroutine

  real(8) function hse_walltime()
    integer(int64) :: count,rate
    call system_clock(count,rate)
    hse_walltime=real(count,8)/real(rate,8)
  end function

  logical function hse_enabled()
    hse_enabled=trim(xc)=='hse06'
  end function

  subroutine hse_pack(psi,mg,info,a)
    type(s_orbital),intent(in) :: psi
    type(s_rgrid),intent(in) :: mg
    type(s_parallel_info),intent(in) :: info
    complex(8),intent(out) :: a(:,:,:)
    integer :: ik,io,is(3),ie(3)
    is=mg%is;ie=mg%ie
    do ik=info%ik_s,info%ik_e;do io=info%io_s,info%io_e
      a(:,io-info%io_s+1,ik-info%ik_s+1)=reshape( &
        psi%zwf(is(1):ie(1),is(2):ie(2),is(3):ie(3),1,io,ik,1),[product(mg%num)])
    enddo;enddo
  end subroutine

  subroutine hse_unpack(a,psi,mg,info)
    complex(8),intent(in) :: a(:,:,:)
    type(s_orbital),intent(inout) :: psi
    type(s_rgrid),intent(in) :: mg
    type(s_parallel_info),intent(in) :: info
    integer :: ik,io,is(3),ie(3)
    is=mg%is;ie=mg%ie
    do ik=info%ik_s,info%ik_e;do io=info%io_s,info%io_e
      psi%zwf(is(1):ie(1),is(2):ie(2),is(3):ie(3),1,io,ik,1)= &
        reshape(a(:,io-info%io_s+1,ik-info%ik_s+1),mg%num)
    enddo;enddo
    psi%update_zwf_overlap=.false.
  end subroutine

  subroutine hse_refresh(system,mg,info,psi)
    type(s_dft_system),intent(in) :: system
    type(s_rgrid),intent(in) :: mg
    type(s_parallel_info),intent(in) :: info
    type(s_orbital),intent(in) :: psi
    complex(8),allocatable :: w(:,:,:),local(:,:,:)
    real(8) :: ex,offdiag(3,3),tick,communication_before
    integer :: ierr,total_error,ng,nk,no,n,mesh,j,first_full,count_full
    if(.not.hse_enabled().or.hse_freeze)return
    if(info%isize_r/=1.or.info%isize_o/=1.or.info%numm/=1) &
      error stop 'HSE06: initial native support requires k-only MPI distribution'
    if(yn_periodic/='y'.or.system%nspin/=1.or..not.allocated(psi%zwf)) &
      error stop 'HSE06: periodic complex unpolarized orbitals required'
    if(yn_spinorbit/='n'.or.yn_jm/='n'.or.yn_dc/='n'.or.yn_md/='n'.or.yn_symmetrized_stencil=='y') &
      error stop 'HSE06: unsupported Hamiltonian/ionic extension'
    if(PLUS_U_ON)error stop 'HSE06: DFT+U combination unsupported'
    if(allocated(system%Ac_micro%v))error stop 'HSE06: microscopic vector potential unsupported'
    ng=product(mg%num);nk=system%nk;no=system%no;n=mg%num(1);mesh=nint(real(nk,8)**(1d0/3d0))
    if(use_symmetry)mesh=num_kgrid(1)
    if(any(mg%num/=n).or.(.not.use_symmetry.and.mesh**3/=nk).or. &
      maxval(abs(system%hgs-system%hgs(1)))>1d-12) &
      error stop 'HSE06: cubic grid and full cubic k mesh required'
    offdiag=system%primitive_a
    do j=1,3;offdiag(j,j)=0;enddo
    if(maxval(abs(offdiag))>1d-12)error stop 'HSE06: orthogonal cell required'
    if((.not.use_symmetry.and.maxval(abs(system%wtk-1d0/nk))>1d-12).or. &
      maxval(abs(system%rocc-2d0))>1d-12) &
      error stop 'HSE06: uniform k weights and fully occupied spin pairs required'
    if(info%io_s/=1.or.info%io_e/=no.or.info%numk<1)error stop 'HSE06: unsupported orbital layout'
    if(kernel%n==0)then
      ! Keep representatives persistent; expand only rank-local stars for EXX.
      if(use_symmetry)then
        if(any(num_kgrid/=mesh))error stop 'HSE symmetry: cubic full mesh required'
        call symmetry_init(symmetry_map,mg%num,system%hgs,system%vec_k(:,:nk),system%wtk(:nk), &
          SymMatA,SymMatB,mesh,ierr)
        call comm_summation(ierr,total_error,info%icomm_rko)
        if(total_error/=0)error stop 'HSE symmetry: invalid grid, stars or weights'
        call symmetry_validate_atoms(symmetry_map,system%Rion,system%kion,ierr)
        call comm_summation(ierr,total_error,info%icomm_rko)
        if(total_error/=0)error stop 'HSE symmetry: operation does not preserve atoms'
        first_full=symmetry_map%first(info%ik_s)
        count_full=symmetry_map%first(info%ik_e+1)-first_full
        call hse_kernel_init(kernel,n,mesh,system%hgs(1),symmetry_map%full_k,hse_omega, &
          max(1,min(16,64/info%isize_k)),ierr,first_full,count_full)
      else
        call hse_kernel_init(kernel,n,mesh,system%hgs(1),system%vec_k,hse_omega, &
          max(1,min(16,64/info%isize_k)),ierr,info%ik_s,info%numk)
      endif
      call comm_summation(ierr,total_error,info%icomm_rko)
      if(total_error/=0)error stop 'HSE06: kernel initialization failed'
      timing_enabled=kernel%profile
    endif
    allocate(local(ng,no,info%numk))
    call hse_pack(psi,mg,info,local)
    ierr=1
    if(allocated(cached_source))then
      if(all(shape(cached_source)==shape(local)))then
        if(all(cached_source==local))ierr=0
      endif
    endif
    call comm_summation(ierr,total_error,info%icomm_k)
    if(total_error==0)return
    allocate(w(ng,no,info%numk))
    if(timing_enabled)then
      tick=hse_walltime();communication_before=hse_timings(4)
    endif
    call apply_distributed(local,local,w,info,ierr)
    if(timing_enabled)hse_timings(1)=hse_timings(1)+hse_walltime()-tick-(hse_timings(4)-communication_before)
    call comm_summation(ierr,total_error,info%icomm_k)
    if(total_error/=0)error stop 'HSE06: distributed exchange action failed'
    if(kernel%profile.and.info%id_k==0)write(*,'(a,i0,a,6es14.5)') &
      'HSE_PROFILE rank0 block=',kernel%block,' density comm fft kernel packing action=',kernel%seconds
    if(.not.reported_team.and.info%id_k==0)write(*,'(a,i0)')'HSE_OPENMP threads=',kernel%threads_used
    if(.not.reported_team.and.info%id_k==0)write(*,'(a,l1)')'HSE_FFT_CONTIGUOUS=',kernel%contiguous_fft
    if(.not.reported_team.and.info%id_k==0.and.kernel%auto_fft) &
      write(*,'(a,2es14.5)')'HSE_FFT_AUTO trial strided contiguous seconds=',kernel%fft_trial_seconds
    reported_team=.true.
    if(timing_enabled)tick=hse_walltime()
    call hse_ace_build(ace,local,w,system%hvol,ierr)
    if(timing_enabled)hse_timings(2)=hse_timings(2)+hse_walltime()-tick
    call comm_summation(ierr,total_error,info%icomm_k)
    if(total_error/=0)error stop 'HSE06: ACE metric failed'
    cached_source=local
    ex=0d0
    do j=1,info%numk
      ex=ex+.25d0*real(sum(conjg(local(:,:,j))*w(:,:,j)),8)*system%hvol*system%wtk(info%ik_s+j-1)
    enddo
    call comm_summation(ex,hse_exchange_energy,info%icomm_k)
  end subroutine

  subroutine apply_distributed(source,target,action,info,ierr)
    complex(8),intent(in) :: source(:,:,:),target(:,:,:)
    complex(8),intent(out) :: action(:,:,:)
    type(s_parallel_info),intent(in) :: info
    integer,intent(out) :: ierr
    integer :: local_layout(2*info%isize_k),layout(2*info%isize_k),np,j,index,total_error
    complex(8),allocatable :: expanded_target(:,:,:),expanded_action(:,:,:),rotated(:,:)
    np=info%isize_k;local_layout=0
    local_layout(info%id_k+1)=info%ik_s
    local_layout(np+info%id_k+1)=info%numk
    if(use_symmetry)then
      local_layout(info%id_k+1)=symmetry_map%first(info%ik_s)
      local_layout(np+info%id_k+1)=symmetry_map%first(info%ik_e+1)-symmetry_map%first(info%ik_s)
    endif
    call comm_summation(local_layout,layout,size(layout),info%icomm_k)
    if(use_symmetry)then
      ierr=0
      if(.not.all(ieee_is_finite(real(source))).or..not.all(ieee_is_finite(aimag(source))))ierr=1
      call comm_summation(ierr,total_error,info%icomm_k)
      if(total_error/=0)then
        ierr=1;return
      endif
      allocate(expanded_target(size(target,1),size(target,2),layout(np+info%id_k+1)))
      allocate(rotated(size(source,1),size(source,2)))
      do j=1,size(expanded_target,3)
        index=layout(info%id_k+1)+j-1
        call symmetry_transform(symmetry_map,index,1,target(:,:,symmetry_map%owner(index)-info%ik_s+1), &
          expanded_target(:,:,j),ierr)
        if(ierr/=0)error stop 'HSE symmetry target transformation failed'
      enddo
      allocate(expanded_action(size(expanded_target,1),size(expanded_target,2),size(expanded_target,3)))
      ! Source argument is only a valid layout placeholder when the density callback is supplied.
      call hse_kernel_apply_distributed(kernel,expanded_target,expanded_target,expanded_action,layout(:np), &
        layout(np+1:),info%id_k,transpose_tiles,ierr,fill_density)
      if(ierr==0)then
        do j=1,info%numk
          index=symmetry_map%first(info%ik_s+j-1)-symmetry_map%first(info%ik_s)+1
          action(:,:,j)=expanded_action(:,:,index)
        enddo
      endif
      return
    endif
    call hse_kernel_apply_distributed(kernel,source,target,action,layout(:np),layout(np+1:), &
      info%id_k,transpose_tiles,ierr)
  contains
    subroutine fill_density(j,lo,rows,density)
      integer,intent(in) :: j,lo,rows
      complex(8),intent(out) :: density(:,:)
      integer :: full_index,rep,op,g,stat,ng,no
      complex(8) :: coefficient
      external :: zgemm
      ng=size(source,1);no=size(source,2)
      full_index=layout(info%id_k+1)+j-1
      rep=symmetry_map%owner(full_index)-info%ik_s+1
      coefficient=cmplx(1d0/symmetry_map%multiplicity(full_index),0d0,8)
      density=0d0
      ! Average little-group projectors one orbital block at a time, not copies of all orbitals.
      do op=1,symmetry_map%multiplicity(full_index)
        call symmetry_transform(symmetry_map,full_index,op,source(:,:,rep),rotated,stat)
        if(stat/=0)error stop 'HSE symmetry source transformation failed'
        do g=1,no
          rotated(:,g)=rotated(:,g)*kernel%phase(:,j)
        enddo
        call zgemm('N','C',rows,ng,no,coefficient,rotated(lo,1),ng,rotated(1,1),ng, &
          (1d0,0d0),density(1,1),size(density,1))
      enddo
    end subroutine
    subroutine transpose_tiles(send,recv,count)
      complex(8),intent(in) :: send(:)
      complex(8),intent(out) :: recv(:)
      integer,intent(in) :: count
      real(8) :: start
      if(timing_enabled)start=hse_walltime()
      call comm_alltoall(send,recv,info%icomm_k,count)
      if(timing_enabled)hse_timings(4)=hse_timings(4)+hse_walltime()-start
    end subroutine
  end subroutine

  subroutine hse_add_action(psi,hpsi,system,mg,info)
    type(s_orbital),intent(in) :: psi
    type(s_orbital),intent(inout) :: hpsi
    type(s_dft_system),intent(in) :: system
    type(s_rgrid),intent(in) :: mg
    type(s_parallel_info),intent(in) :: info
    integer :: ierr,ng,total_error
    real(8) :: tick,communication_before
    if(.not.hse_enabled())return
    if(.not.allocated(ace%factors))error stop 'HSE06: occupied exchange source is not initialized'
    ng=product(mg%num)
    if(allocated(target_work))then
      if(any(shape(target_work)/=[ng,info%numo,info%numk]))deallocate(target_work,action_work,output_work)
    endif
    if(.not.allocated(target_work))allocate(target_work(ng,info%numo,info%numk), &
      action_work(ng,info%numo,info%numk),output_work(ng,info%numo,info%numk))
    call hse_pack(psi,mg,info,target_work)
    if(timing_enabled)tick=hse_walltime()
    if(taylor_active.and.taylor_midpoint)then
      call hse_ace_apply(midpoint_ace,target_work,action_work,ierr)
    else
      call hse_ace_apply(ace,target_work,action_work,ierr)
    endif
    if(timing_enabled)hse_timings(3)=hse_timings(3)+hse_walltime()-tick
    if(ierr/=0)error stop 'HSE06: ACE application failed'
    call hse_pack(hpsi,mg,info,output_work)
    output_work=output_work+.25d0*action_work
    call hse_unpack(output_work,hpsi,mg,info)
  end subroutine
end module

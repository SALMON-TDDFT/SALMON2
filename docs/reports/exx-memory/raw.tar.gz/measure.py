from pathlib import Path
import json,os,shutil,subprocess,sys,hashlib,time
repo=Path.cwd();origin=(repo/'../work/h2-block-source-ace-reused-full').resolve();out=(repo/'../work/h2-exx-memory-final').resolve();out.mkdir(exist_ok=True)
binary=(repo/'../work/pbeh40-scalapack-build/salmon').resolve();old=json.loads((origin/'results.json').read_text())
sys.path.insert(0,str(repo/'testsuites/benchmark_h2_pbeh_rt'));from run_rt import parse_rt
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
data=dict(binary_sha256=sha(binary),production_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),reference_results_sha256=sha(origin/'results.json'),reference_binary_sha256=old['binary_sha256'],scope='8/64/128 H2 memory reduction, source ACE only',runs=[])
for shape,ranks,repeats in [([1,1,1],1,3),([8,1,1],8,1),([16,1,1],16,1)]:
 for rep in range(1,repeats+1):
  reference=next(r for r in old['runs'] if r['shape']==shape and r['ranks']==ranks and r['mode']=='adaptive' and r['repeat']==rep)
  tag=reference['folder'];src=origin/tag;folder=out/tag;folder.mkdir()
  prep=next(p for p in old['preparations'] if p['shape']==shape)
  for name,h in prep['payload_sha256'].items():assert sha(origin/prep['folder']/name)==h
  shutil.copy(src/'inputfile',folder);shutil.copy(src/'H_rps.dat',folder)
  (folder/'data_dcdft').symlink_to((src/'data_dcdft').resolve(),target_is_directory=True)
  print('START',tag,flush=True);start=time.perf_counter()
  with (folder/'inputfile').open() as fin,(folder/'output').open('w') as fout:
   run=subprocess.run(['/opt/homebrew/bin/mpiexec','--bind-to','none','-n',str(ranks),sys.executable,str(repo/'testsuites/benchmark_h2_pbeh/rank_probe.py'),str(binary)],cwd=folder,stdin=fin,stdout=fout,stderr=subprocess.STDOUT,env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1'))
  assert run.returncode==0
  r=parse_rt(folder,ranks,max_energy_width=None);text=(folder/'output').read_text()
  assert text.count('EXX_SUPPORT_ACE accepted: T')==33 and 'EXX_SUPPORT_ACE accepted: F' not in text
  current=max(abs(a-b) for u,v in zip(reference['observables'],r['observables']) for a,b in zip(u[13:16],v[13:16]));energy=max(abs(u[1]-v[1]) for u,v in zip(reference['energies'],r['energies']))
  assert current<2e-8 and energy<2e-8,(current,energy)
  r.update(shape=shape,ranks=ranks,repeat=rep,folder=tag,reference=reference,max_current_difference=current,max_energy_difference_ha=energy,launcher_wall_seconds=time.perf_counter()-start)
  data['runs'].append(r);(out/'results.json').write_text(json.dumps(data,indent=2)+'\n')
  print('DONE',tag,r['rt_max_seconds'],r['peak_rank_bytes']/2**20,'difference',current,energy,flush=True)
data['complete']=True;(out/'results.json').write_text(json.dumps(data,indent=2)+'\n')

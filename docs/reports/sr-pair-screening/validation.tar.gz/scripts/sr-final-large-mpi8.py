import sys,os,json,shutil,subprocess
from pathlib import Path
repo=Path.cwd();sys.path.insert(0,str(repo/'testsuites/benchmark_h2_pbeh_rt'))
from run_rt import parse_rt
base=repo/'../work/h2-pbeh-rt/adaptive-measured';dest=repo/'../work/sr-final-large-mpi8';dest.mkdir(exist_ok=True)
exe=(repo/'../work/pbeh40-scalapack-build/salmon').resolve();seed=(repo/'../work/h2-pbeh-rt/measured/gs-4x4x1/data_dcdft').resolve()
results=[]
for ranks in (8,):
 for mode in ('full','adaptive'):
  name=f'{mode}-4x4x1-mpi{ranks}-r1';folder=dest/name;folder.mkdir()
  shutil.copy(base/name/'inputfile',folder);shutil.copy(repo/'testsuites/pseudo/H_rps.dat',folder)
  (folder/'data_dcdft').symlink_to(seed,target_is_directory=True)
  with (folder/'inputfile').open() as fin,(folder/'output').open('w') as fout:
   run=subprocess.run(['mpiexec','--bind-to','none','-n',str(ranks),sys.executable,str(repo/'testsuites/benchmark_h2_pbeh/rank_probe.py'),str(exe)],stdin=fin,stdout=fout,stderr=subprocess.STDOUT,cwd=folder,timeout=300,env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
  assert run.returncode==0,name
  r=parse_rt(folder,ranks,None);r.update(mode=mode,ranks=ranks,folder=name)
  out=(folder/'output').read_text();r['retained_gauges']=out.count('retained accepted transported gauge')
  r['active_refreshes']=out.count('EXX_ADAPTIVE fraction/max radius')
  assert r['active_refreshes']==33
  results.append(r);(dest/'results.json').write_text(json.dumps(results,indent=2)+'\n')
  print(name,'energy width',r['post_impulse_energy_width_ha'],'retained gauges',r['retained_gauges'],flush=True)

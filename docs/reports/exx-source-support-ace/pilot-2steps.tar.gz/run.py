from pathlib import Path
import json,os,re,shutil,subprocess,sys,hashlib
import numpy as np
repo=Path.cwd();root=(repo/'../work/h2-source-ace-pilot').resolve();root.mkdir(exist_ok=True)
old=(repo/'../work/h2-block-scaling-measured').resolve();binary=(repo/'../work/pbeh40-scalapack-build/salmon').resolve()
seed=old/'gs-8x1x1';original=(old/'adaptive-8x1x1-mpi8-r1/inputfile').read_text();assert 'nt=16' in original
record=dict(binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),steps=2,shape=[8,1,1],ranks=8,tolerance=1e-6,runs=[])
for mode in ('occupied','source'):
 folder=root/mode;folder.mkdir();shutil.copy(repo/'testsuites/pseudo/H_rps.dat',folder)
 (folder/'data_dcdft').symlink_to(seed/'data_dcdft',target_is_directory=True)
 inp=original.replace('nt=16','nt=2').replace('&functional',f"&functional\n exx_ace_support='{mode}'")
 (folder/'inputfile').write_text(inp)
 with (folder/'inputfile').open() as fin,(folder/'output').open('w') as fout:
  run=subprocess.run(['/opt/homebrew/bin/mpiexec','--bind-to','none','-n','8',sys.executable,str(repo/'testsuites/benchmark_h2_pbeh/rank_probe.py'),str(binary)],cwd=folder,stdin=fin,stdout=fout,stderr=subprocess.STDOUT,env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1'))
 assert run.returncode==0
 text=(folder/'output').read_text();assert 'end SALMON' in text
 obs=np.loadtxt(folder/'h2_rt.data');energy=np.loadtxt(folder/'h2_rt_energy.data');assert len(obs)==2 and len(energy)==3
 rows=[json.loads((folder/f'rank-{i}.json').read_text()) for i in range(8)];assert all(r['returncode']==0 for r in rows)
 r=dict(mode=mode,rt_seconds=float(re.search(r'^\s*rt iterations\s+\S+\s+(\S+)',text,re.M)[1]),peak_rank_bytes=max(r['peak_rss_bytes'] for r in rows),
     support_accepted=text.count('EXX_SUPPORT_ACE accepted: T'),support_rejected=text.count('EXX_SUPPORT_ACE accepted: F'),support_counts=[list(map(int,x)) for x in re.findall(r'EXX_SUPPORT_ACE products/skipped/catalogue/product points:\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)',text)],pairs=[list(map(int,x)) for x in re.findall(r'EXX_PAIR generated grid products/catalogue entries:\s+(\d+)\s+(\d+)',text)],
     executed=[list(map(int,x)) for x in re.findall(r'EXX_ADAPTIVE local/global pairs/local FFT points \(orbital group 0\):\s+(\d+)\s+(\d+)\s+(\d+)',text)],
     bounds=[float(x) for x in re.findall(r'EXX_PAIR unscreened ACE fallback: [TF] accepted action bound:\s+(\S+)',text)],fallbacks=text.count('EXX_PAIR unscreened ACE fallback: T'),observables=obs.tolist(),energies=energy.tolist())
 record['runs'].append(r);(root/'results.json').write_text(json.dumps(record,indent=2)+'\n');print(mode,r['rt_seconds'],r['peak_rank_bytes']/2**20,r['pairs'],r['fallbacks'],flush=True)
f,a=record['runs'];record['current_difference']=float(np.max(abs(np.array(f['observables'])[:,13:16]-np.array(a['observables'])[:,13:16])));record['energy_difference_ha']=float(np.max(abs(np.array(f['energies'])[:,1]-np.array(a['energies'])[:,1])));(root/'results.json').write_text(json.dumps(record,indent=2)+'\n');print('differences',record['current_difference'],record['energy_difference_ha'],flush=True)
